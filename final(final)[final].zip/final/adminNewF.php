<!DOCTYPE html>
<html>
<head>
<title>check check one two</title>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.cs'>
</head>
<body>
    <p>Create a new admin account</p>
</body>
<form action='registerB.php' method='POST'>
    <p><input placeholder='username' name='username'></p>
    <p><input type='password' placeholder="password" name='password'></p>
    <p><input type='submit' value = 'submit'>submit</button></p>
</form>
</html>