<!DOCTYPE html>
<html>
<head>
<title>check check one three</title>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.cs'>
</head>
<div class="w3-container w3-blue">
    <p>login</p>
</div>
<form action='indexB.php' method='POST'>
    <p><input placeholder='username' name='username'></p>
    <p><input type='password' placeholder="password" name='password'></p>
    <p><input type='submit' value = 'submit'></p>
</form>
<body>
    <p>register account</p>
</body>
<a href="registerF.php">Click here</a>
</html>