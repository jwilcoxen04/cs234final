<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    change what some guy likes
</body>
<form action='adminModB.php' method='POST'>
    <p><input placeholder='username' name='username'></p>
    <p><input placeholder="thing" name='thing'></p>
    <p><input type='submit' value = 'submit'>submit</button></p>
</form>
</html>